# How to Work with LaTeX Files

## Opening .tex Files

### In Cursor/VS Code (Current Editor)
1. **Simply click on any .tex file** in the file explorer
2. Files will open in the editor with syntax highlighting
3. You can edit them directly

### Main Files to Know:
- **`main.tex`** - Main document file (start here!)
- **`chapters/related-work.tex`** - Chapter 1: Literature Survey
- **`chapters/data.tex`** - Chapter 2: Data
- **`preamble/thesis-details.tex`** - Your thesis title, name, etc.

## Viewing the Compiled PDF

To see your thesis as a PDF, you need to compile the LaTeX files. Here are your options:

### Option 1: Install LaTeX on macOS (Recommended)

#### Using MacTeX (Full Installation)
```bash
# Download from: https://www.tug.org/mactex/
# Or install via Homebrew:
brew install --cask mactex
```

#### Using BasicTeX (Smaller Installation)
```bash
brew install --cask basictex
# Then install additional packages:
sudo tlmgr update --self
sudo tlmgr install collection-fontsrecommended
```

### Option 2: Online LaTeX Editors (No Installation Needed)

1. **Overleaf** (https://www.overleaf.com/)
   - Free online LaTeX editor
   - Upload your files
   - Compiles automatically
   - Great for collaboration

2. **TeXPage** (https://texpage.com/)
   - Simple online compiler

### Option 3: VS Code Extension

Install the **LaTeX Workshop** extension in Cursor/VS Code:
1. Open Extensions (Cmd+Shift+X)
2. Search for "LaTeX Workshop"
3. Install it
4. It will compile and preview PDFs automatically

## Compiling Your Thesis

### From Terminal (if LaTeX is installed):

```bash
cd /Users/rajakarthikchirumamilla/Documents/ThesisWork/etl-ai-schema/Documentation

# Compile main.tex
pdflatex main.tex

# If you have bibliography (you do), run these commands:
bibtex main
pdflatex main.tex
pdflatex main.tex

# Or use latexmk (automates everything):
latexmk -pdf main.tex
```

### Using LaTeX Workshop Extension:

1. Open `main.tex`
2. Press `Cmd+Option+B` (or right-click → "Build LaTeX project")
3. PDF will be generated automatically
4. Press `Cmd+Option+V` to view PDF

## File Structure

```
Documentation/
├── main.tex                    ← Main file (compile this!)
├── srhthesis.cls              ← Document class
├── preamble/
│   ├── thesis-details.tex     ← Your info (title, name)
│   ├── packages.tex           ← LaTeX packages
│   └── bib-setup.tex          ← Bibliography setup
├── chapters/
│   ├── related-work.tex       ← Chapter 1 (Literature Survey)
│   ├── data.tex               ← Chapter 2 (Data)
│   ├── introduction.tex
│   ├── method.tex
│   └── ...
└── bib/
    └── references.bib         ← Your citations
```

## Quick Start Guide

1. **Edit your thesis details:**
   ```bash
   # Open this file:
   Documentation/preamble/thesis-details.tex
   ```

2. **Edit chapters:**
   ```bash
   # Chapter 1 (Literature Survey):
   Documentation/chapters/related-work.tex
   
   # Chapter 2 (Data):
   Documentation/chapters/data.tex
   ```

3. **Add references:**
   ```bash
   # Edit this file:
   Documentation/bib/references.bib
   ```

4. **Compile to PDF:**
   - Use Overleaf (easiest, no installation)
   - Or install LaTeX and compile locally

## Troubleshooting

### "Command not found: pdflatex"
- Install LaTeX (see Option 1 above)
- Or use Overleaf (no installation needed)

### Missing packages
If you get errors about missing packages:
```bash
sudo tlmgr install <package-name>
```

### Bibliography not showing
Make sure you run:
```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

## Recommended Workflow

1. **Edit in Cursor** - Use your current editor to write/edit .tex files
2. **Compile in Overleaf** - Upload to Overleaf for compilation and PDF viewing
3. **Or use LaTeX Workshop** - Install extension for integrated compilation

## Next Steps

1. Open `main.tex` in Cursor to see the structure
2. Edit `chapters/related-work.tex` and `chapters/data.tex` (already filled in!)
3. Choose a compilation method (Overleaf recommended for beginners)
4. Compile and view your PDF

